__author__ = 'anush0247'


def getDecryptedData(privateKey, jsonDataString):
    return jsonDataString
