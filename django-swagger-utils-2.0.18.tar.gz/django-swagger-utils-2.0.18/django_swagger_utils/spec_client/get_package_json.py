package_json = """
{
 "lockfileVersion": 1,
 "dependencies": {
   "argparse": {
     "integrity": "sha1-c9g7wmP4bpf4zE9rrhsOkKfSLIY=",
     "version": "https://registry.npmjs.org/argparse/-/argparse-1.0.9.tgz"
   },
   "bluebird": {
     "integrity": "sha1-eRQg1/VR7qKJdFOop3ZT+WYG1nw=",
     "version": "https://registry.npmjs.org/bluebird/-/bluebird-3.5.0.tgz"
   },
   "camelcase": {
     "integrity": "sha1-1UVjW+HjPFQmScaRc+Xeas+uNN0=",
     "version": "https://registry.npmjs.org/camelcase/-/camelcase-4.1.0.tgz"
   },
   "esprima": {
     "integrity": "sha1-/cpRzuYTOJXjyI1TXOSdv/YqRjM=",
     "version": "https://registry.npmjs.org/esprima/-/esprima-3.1.3.tgz"
   },
   "js-yaml": {
     "integrity": "sha1-UgtFZPhlc7qWZir4Woyvp7S1pvY=",
     "version": "https://registry.npmjs.org/js-yaml/-/js-yaml-3.8.4.tgz"
   },
   "lodash": {
     "integrity": "sha1-eCA6TRwyiuHYbcpkYONptX9AVa4=",
     "version": "https://registry.npmjs.org/lodash/-/lodash-4.17.4.tgz"
   },
   "minimist": {
     "integrity": "sha1-o1AIsg9BOD7sH7kU9M1d95omQoQ=",
     "version": "https://registry.npmjs.org/minimist/-/minimist-1.2.0.tgz"
   },
   "sprintf-js": {
     "integrity": "sha1-BOaSb2YolTVPPdAVIDYzuFcpfiw=",
     "version": "https://registry.npmjs.org/sprintf-js/-/sprintf-js-1.0.3.tgz"
   },
   "swagger-split": "^1.0.2"
 }
}
"""
