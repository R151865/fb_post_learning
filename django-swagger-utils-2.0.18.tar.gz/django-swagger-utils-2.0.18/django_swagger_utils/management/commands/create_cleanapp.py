import os

from django.core.management.base import BaseCommand

from .custom_app import CreateCustomApp

class CreateCleanApp(CreateCustomApp):
    def get_default_files_list(self):
        folders_list, files_list = super(CreateCleanApp, self).get_default_files_list()
        app_base_path = os.path.join(self.base_path, self.app_name)
        interactors_dir = os.path.join(app_base_path, 'interactors')
        tests_dir = os.path.join(app_base_path, 'tests')
        extra_folders_list = {
            'entities_dir': os.path.join(app_base_path, 'entities/'),
            'storages_dir': os.path.join(app_base_path, 'storages/'),
            'presenters_dir': os.path.join(app_base_path, 'presenters/'),
            'i_presenters': os.path.join(interactors_dir, 'presenters/'),
            'i_storages': os.path.join(interactors_dir, 'storages/'),
            't_entities': os.path.join(tests_dir, 'entities/'),
            't_interactors': os.path.join(tests_dir, 'interactors/'),
            't_presenters': os.path.join(tests_dir, 'presenters/'),
            't_storages': os.path.join(tests_dir, 'storages/'),
            't_views': os.path.join(tests_dir, 'views/'),
        }
        folders_list.pop('validators_dir')
        folders_list.update(extra_folders_list)
        return folders_list, files_list



class Command(BaseCommand):
    can_import_settings = True
    help = 'Generate a clean architecture based template app'

    def add_arguments(self, parser):
        parser.add_argument('apps', nargs='*', type=str, help="List of apps to create")
        parser.add_argument('-p', '--project', type=str, help="Name of the django project",
                            required=True)

    def handle(self, *args, **options):
        from django.conf import settings
        base_dir = settings.BASE_DIR
        try:
            apps = options['apps']
            project = options['project']
            if project not in base_dir:
                self.stderr.write(self.style.ERROR('**** ERROR: Project name is not right ****'))
                exit(1)
            if not apps:
                self.stderr.write("usage: python manage.py create_cleanapp <app_names> ")
                exit(1)
            for app_name in apps:
                create_clean_app = CreateCleanApp(app_name, base_dir,
                                                    project)
                create_clean_app.create_app()
        except Exception as err:
            self.stderr.write(err)
            exit(1)


