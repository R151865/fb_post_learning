def check_path_exists(path):
    """
    returns a bool if path exists
    :param path:
    :return:
    """
    import os
    return os.path.exists(path)
